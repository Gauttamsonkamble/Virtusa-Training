package construcorBasedDI;

public class Movie {
	private int id;  
    private String movieName;  
    public Movie() {System.out.println("Tanhaji");}  
    public Movie(int id) {this.id = id;}  
    public Movie(String movieName) {  this.movieName = movieName;}  
    public Movie(int id, String movieName) {  
        this.id = id;  
        this.movieName = movieName;  
    }  
    public void Set(String movieName) {  
        this.movieName = movieName;  
    } 
    void display(){  
        System.out.println(id+" "+movieName);  
    }  

}
