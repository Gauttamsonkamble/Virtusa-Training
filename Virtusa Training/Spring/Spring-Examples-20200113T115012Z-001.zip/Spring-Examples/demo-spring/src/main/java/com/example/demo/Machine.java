package com.example.demo;

import org.springframework.stereotype.*;

@Component("Mac")
public class Machine {
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Machine [id=" + id + ", name=" + name + "]";
	}
	
	public void use()
	{
		System.out.println("Working Machine !!!");
	}
	

}
