package com.example.demo;
import org.springframework.stereotype.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;	
import org.springframework.context.annotation.Scope;

@Component

public class Person {
	private String name;
	private int age;
	private String occupation;
	
	@Autowired
	@Qualifier("Mac")
	private Machine machine;
	
	
	public Machine getMachine() {
		return machine;
	}
	public void setMachine(Machine machine) {
		this.machine = machine;
	}
	public Person() {
		super();
		System.out.println("object created");
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public void show()
	{
		System.out.println("inside the show");
		machine.use();
	}
}
